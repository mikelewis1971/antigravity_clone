"""Integration tests for Antigravity Local."""
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))


def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")
    
    try:
        import llm_server
        print("[OK] llm_server")
    except ImportError as e:
        print(f"[FAIL] llm_server: {e}")
        return False
    
    try:
        import tools
        print("[OK] tools")
    except ImportError as e:
        print(f"[FAIL] tools: {e}")
        return False
    
    try:
        import agent
        print("[OK] agent")
    except ImportError as e:
        print(f"[FAIL] agent: {e}")
        return False
    
    try:
        import api
        print("[OK] api")
    except ImportError as e:
        print(f"[FAIL] api: {e}")
        return False
    
    return True


def test_config():
    """Test that configuration can be loaded."""
    print("\nTesting configuration...")
    
    try:
        import yaml
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config.yaml')
        
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        # Check required sections
        assert 'llm' in config, "Missing 'llm' section"
        assert 'server' in config, "Missing 'server' section"
        assert 'tools' in config, "Missing 'tools' section"
        
        print("[OK] Configuration valid")
        return True
    except Exception as e:
        print(f"[FAIL] Configuration error: {e}")
        return False


def test_tools_initialization():
    """Test that tools can be initialized."""
    print("\nTesting tools initialization...")
    
    try:
        from tools import ToolExecutor
        
        tool_executor = ToolExecutor()
        tools = tool_executor.get_available_tools()
        
        print(f"[OK] Found {len(tools)} tools:")
        for tool in tools:
            print(f"  - {tool['name']}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Tools initialization error: {e}")
        return False


def main():
    """Run all tests."""
    print("=" * 60)
    print("  Antigravity Local - Integration Tests")
    print("=" * 60)
    print()
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("Configuration", test_config()))
    results.append(("Tools", test_tools_initialization()))
    
    print("\n" + "=" * 60)
    print("Test Results:")
    print("=" * 60)
    
    for name, passed in results:
        status = "[PASS]" if passed else "[FAIL]"
        print(f"{status} - {name}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n[SUCCESS] All tests passed!")
        return 0
    else:
        print("\n[FAILURE] Some tests failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
