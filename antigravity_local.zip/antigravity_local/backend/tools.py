"""Enhanced tool framework with system settings capabilities."""
import os
import subprocess
import json
import winreg
from typing import Dict, List, Any, Optional
import httpx
import yaml


class ToolExecutor:
    """Executes various tools for the agent with enhanced capabilities."""
    
    def __init__(self, config_path: str = "../config.yaml"):
        """Initialize tool executor with configuration."""
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.tool_config = self.config['tools']
        self.workspace_root = self.tool_config['workspace_root']
    
    def get_available_tools(self) -> List[Dict]:
        """Return list of available tools with their schemas."""
        tools = []
        
        if self.tool_config['allow_file_read']:
            tools.append({
                "name": "read_file",
                "description": "Read the contents of a file from the filesystem",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Absolute path to the file to read"
                        }
                    },
                    "required": ["file_path"]
                }
            })
        
        if self.tool_config['allow_file_write']:
            tools.append({
                "name": "write_file",
                "description": "Write content to a file (creates new or overwrites existing)",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Absolute path to the file to write"
                        },
                        "content": {
                            "type": "string",
                            "description": "Content to write to the file"
                        }
                    },
                    "required": ["file_path", "content"]
                }
            })
            
            tools.append({
                "name": "edit_file",
                "description": "Edit specific lines in a file by replacing content",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Absolute path to the file to edit"
                        },
                        "old_content": {
                            "type": "string",
                            "description": "The exact content to replace"
                        },
                        "new_content": {
                            "type": "string",
                            "description": "The new content to insert"
                        }
                    },
                    "required": ["file_path", "old_content", "new_content"]
                }
            })
        
        tools.append({
            "name": "list_directory",
            "description": "List contents of a directory",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory_path": {
                        "type": "string",
                        "description": "Absolute path to the directory to list"
                    }
                },
                "required": ["directory_path"]
            }
        })
        
        tools.append({
            "name": "search_files",
            "description": "Search for files by pattern in a directory",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory_path": {
                        "type": "string",
                        "description": "Directory to search in"
                    },
                    "pattern": {
                        "type": "string",
                        "description": "File pattern to search for (e.g., '*.py')"
                    }
                },
                "required": ["directory_path", "pattern"]
            }
        })
        
        if self.tool_config['allow_command_execution']:
            tools.append({
                "name": "execute_command",
                "description": "Execute a PowerShell command and return the output",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "The PowerShell command to execute"
                        },
                        "working_directory": {
                            "type": "string",
                            "description": "Working directory for command execution (optional)"
                        }
                    },
                    "required": ["command"]
                }
            })
            
            tools.append({
                "name": "get_system_info",
                "description": "Get system information (OS, CPU, memory, etc.)",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            })
        
        if self.tool_config.get('allow_registry_access', False):
            tools.append({
                "name": "read_registry",
                "description": "Read a Windows registry value",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "key_path": {
                            "type": "string",
                            "description": "Registry key path (e.g., 'SOFTWARE\\Microsoft\\Windows\\CurrentVersion')"
                        },
                        "value_name": {
                            "type": "string",
                            "description": "Name of the registry value to read"
                        }
                    },
                    "required": ["key_path", "value_name"]
                }
            })
        
        if self.tool_config['allow_web_requests']:
            tools.append({
                "name": "fetch_url",
                "description": "Fetch content from a URL using HTTP GET request",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to fetch"
                        }
                    },
                    "required": ["url"]
                }
            })
            
            tools.append({
                "name": "search_web",
                "description": "Search the web (simulate with DuckDuckGo)",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        }
                    },
                    "required": ["query"]
                }
            })
        
        return tools
    
    async def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool with given arguments."""
        try:
            if tool_name == "read_file":
                return await self._read_file(arguments['file_path'])
            elif tool_name == "write_file":
                return await self._write_file(arguments['file_path'], arguments['content'])
            elif tool_name == "edit_file":
                return await self._edit_file(
                    arguments['file_path'],
                    arguments['old_content'],
                    arguments['new_content']
                )
            elif tool_name == "list_directory":
                return await self._list_directory(arguments['directory_path'])
            elif tool_name == "search_files":
                return await self._search_files(
                    arguments['directory_path'],
                    arguments['pattern']
                )
            elif tool_name == "execute_command":
                return await self._execute_command(
                    arguments['command'],
                    arguments.get('working_directory')
                )
            elif tool_name == "get_system_info":
                return await self._get_system_info()
            elif tool_name == "read_registry":
                return await self._read_registry(
                    arguments['key_path'],
                    arguments['value_name']
                )
            elif tool_name == "fetch_url":
                return await self._fetch_url(arguments['url'])
            elif tool_name == "search_web":
                return await self._search_web(arguments['query'])
            else:
                return {"success": False, "error": f"Unknown tool: {tool_name}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _read_file(self, file_path: str) -> Dict:
        """Read a file from the filesystem."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return {"success": True, "content": content}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _write_file(self, file_path: str, content: str) -> Dict:
        """Write content to a file."""
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return {"success": True, "message": f"File written: {file_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _edit_file(self, file_path: str, old_content: str, new_content: str) -> Dict:
        """Edit a file by replacing content."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if old_content not in content:
                return {"success": False, "error": "Old content not found in file"}
            
            new_file_content = content.replace(old_content, new_content, 1)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_file_content)
            
            return {"success": True, "message": f"File edited: {file_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _list_directory(self, directory_path: str) -> Dict:
        """List contents of a directory."""
        try:
            items = os.listdir(directory_path)
            
            result = {
                "files": [],
                "directories": []
            }
            
            for item in items:
                full_path = os.path.join(directory_path, item)
                if os.path.isfile(full_path):
                    result["files"].append(item)
                elif os.path.isdir(full_path):
                    result["directories"].append(item)
            
            return {"success": True, "contents": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _search_files(self, directory_path: str, pattern: str) -> Dict:
        """Search for files matching a pattern."""
        try:
            import fnmatch
            matches = []
            
            for root, dirs, files in os.walk(directory_path):
                for filename in fnmatch.filter(files, pattern):
                    matches.append(os.path.join(root, filename))
            
            return {"success": True, "matches": matches[:50]}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _execute_command(self, command: str, working_directory: Optional[str] = None) -> Dict:
        """Execute a PowerShell command."""
        try:
            timeout = self.tool_config['command_timeout']
            cwd = working_directory or self.workspace_root
            
            result = subprocess.run(
                ["powershell", "-Command", command],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd
            )
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Command timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _get_system_info(self) -> Dict:
        """Get system information."""
        try:
            import platform
            import psutil
            
            info = {
                "os": platform.system(),
                "os_version": platform.version(),
                "machine": platform.machine(),
                "processor": platform.processor(),
                "cpu_count": psutil.cpu_count(),
                "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                "memory_available_gb": round(psutil.virtual_memory().available / (1024**3), 2),
                "disk_usage": {}
            }
            
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    info["disk_usage"][partition.device] = {
                        "total_gb": round(usage.total / (1024**3), 2),
                        "used_gb": round(usage.used / (1024**3), 2),
                        "free_gb": round(usage.free / (1024**3), 2)
                    }
                except:
                    pass
            
            return {"success": True, "info": info}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _read_registry(self, key_path: str, value_name: str) -> Dict:
        """Read a Windows registry value."""
        try:
            # Parse key path to determine root key
            parts = key_path.split('\\', 1)
            root_key_name = parts[0]
            subkey_path = parts[1] if len(parts) > 1 else ""
            
            # Map root key names to constants
            root_keys = {
                "HKEY_CURRENT_USER": winreg.HKEY_CURRENT_USER,
                "HKEY_LOCAL_MACHINE": winreg.HKEY_LOCAL_MACHINE,
                "HKEY_CLASSES_ROOT": winreg.HKEY_CLASSES_ROOT,
                "HKEY_USERS": winreg.HKEY_USERS,
                "HKEY_CURRENT_CONFIG": winreg.HKEY_CURRENT_CONFIG,
            }
            
            root_key = root_keys.get(root_key_name)
            if not root_key:
                return {"success": False, "error": f"Invalid root key: {root_key_name}"}
            
            key = winreg.OpenKey(root_key, subkey_path, 0, winreg.KEY_READ)
            value, value_type = winreg.QueryValueEx(key, value_name)
            winreg.CloseKey(key)
            
            return {
                "success": True,
                "value": value,
                "type": value_type
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _fetch_url(self, url: str) -> Dict:
        """Fetch content from a URL."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=10.0)
                return {
                    "success": True,
                    "status_code": response.status_code,
                    "content": response.text[:5000]
                }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _search_web(self, query: str) -> Dict:
        """Search the web (simulate with DuckDuckGo HTML)."""
        try:
            search_url = f"https://lite.duckduckgo.com/lite?q={query}"
            async with httpx.AsyncClient() as client:
                response = await client.get(search_url, timeout=10.0)
                # Simple parsing - just return first 2000 chars
                return {
                    "success": True,
                    "results": response.text[:2000],
                    "query": query
                }
        except Exception as e:
            return {"success": False, "error": str(e)}
