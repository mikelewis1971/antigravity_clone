"""Enhanced FastAPI server with multi-agent and model management support."""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import yaml
from pathlib import Path
from typing import Optional

from llm_server import LLMServer
from tools import ToolExecutor
from agent import AgentManager


# Request models
class CreateAgentRequest(BaseModel):
    name: str

class SwitchModelRequest(BaseModel):
    model_path: str

class MessageRequest(BaseModel):
    content: str
    agent_id: Optional[str] = None


# Initialize FastAPI app
app = FastAPI(title="Antigravity Local Enhanced", version="2.0.0")

# Load configuration
config_path = Path(__file__).parent.parent / "config.yaml"
with open(config_path, 'r') as f:
    config = yaml.safe_load(f)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=config['server']['cors_origins'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
llm_server = None
tool_executor = None
agent_manager = None


@app.on_event("startup")
async def startup_event():
    """Initialize the LLM and agent manager on startup."""
    global llm_server, tool_executor, agent_manager
    
    print("Initializing Antigravity Local Enhanced...")
    llm_server = LLMServer(str(config_path))
    tool_executor = ToolExecutor(str(config_path))
    agent_manager = AgentManager(llm_server, tool_executor)
    print("[OK] System ready with multi-agent support!")


@app.get("/")
async def read_root():
    """Serve the main page."""
    frontend_path = Path(__file__).parent.parent / "frontend" / "index.html"
    with open(frontend_path, 'r') as f:
        return HTMLResponse(content=f.read())


@app.get("/api/status")
async def get_status():
    """Get system status."""
    model_info = llm_server.get_model_info() if llm_server else {}
    return JSONResponse({
        "status": "ready" if llm_server else "initializing",
        "model": model_info,
        "tools": len(tool_executor.get_available_tools()) if tool_executor else 0,
        "agents": len(agent_manager.list_agents()) if agent_manager else 0
    })


@app.get("/api/tools")
async def get_tools():
    """Get available tools."""
    if tool_executor:
        tools = tool_executor.get_available_tools()
        return JSONResponse({"tools": tools})
    return JSONResponse({"tools": []})


@app.get("/api/models")
async def get_models():
    """Get available models."""
    if llm_server:
        models = llm_server.list_available_models()
        current_model = llm_server.get_model_info()
        return JSONResponse({
            "models": models,
            "current": current_model.get('model_name')
        })
    return JSONResponse({"models": [], "current": None})


@app.post("/api/models/switch")
async def switch_model(request: SwitchModelRequest):
    """Switch to a different model."""
    if llm_server:
        success = llm_server.switch_model(request.model_path)
        return JSONResponse({
            "success": success,
            "current_model": llm_server.get_model_info().get('model_name')
        })
    return JSONResponse({"success": False, "error": "LLM server not initialized"})


@app.get("/api/agents")
async def get_agents():
    """Get list of all agents."""
    if agent_manager:
        agents = agent_manager.list_agents()
        return JSONResponse({"agents": agents})
    return JSONResponse({"agents": []})


@app.post("/api/agents/create")
async def create_agent(request: CreateAgentRequest):
    """Create a new agent."""
    if agent_manager:
        agent_id = agent_manager.create_agent(request.name)
        return JSONResponse({
            "success": True,
            "agent_id": agent_id
        })
    return JSONResponse({"success": False, "error": "Agent manager not initialized"})


@app.delete("/api/agents/{agent_id}")
async def delete_agent(agent_id: str):
    """Delete an agent."""
    if agent_manager:
        success = agent_manager.delete_agent(agent_id)
        return JSONResponse({"success": success})
    return JSONResponse({"success": False})


@app.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):
    """WebSocket endpoint for chat interactions with multi-agent support."""
    await websocket.accept()
    
    try:
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            if message_data.get('type') == 'message':
                user_message = message_data.get('content', '')
                agent_id = message_data.get('agent_id')
                
                # Get or create default agent
                if not agent_id:
                    agents = agent_manager.list_agents()
                    agent_id = agents[0]['id'] if agents else agent_manager.create_agent("Main Agent")
                
                agent = agent_manager.get_agent(agent_id)
                if not agent:
                    await websocket.send_text(json.dumps({
                        'type': 'error',
                        'message': 'Agent not found'
                    }))
                    continue
                
                # Process the message through the agent
                async for response in agent.process_message(user_message):
                    # Send each response chunk to the client
                    await websocket.send_text(json.dumps(response))
                
                # Send completion signal
                await websocket.send_text(json.dumps({
                    'type': 'complete',
                    'agent_id': agent_id
                }))
            
            elif message_data.get('type') == 'reset':
                agent_id = message_data.get('agent_id')
                if agent_id:
                    agent = agent_manager.get_agent(agent_id)
                    if agent:
                        agent.conversation_history = []
                await websocket.send_text(json.dumps({
                    'type': 'reset_complete',
                    'message': 'Conversation reset'
                }))
    
    except WebSocketDisconnect:
        print("Client disconnected")
    except Exception as e:
        print(f"WebSocket error: {e}")
        await websocket.send_text(json.dumps({
            'type': 'error',
            'message': str(e)
        }))


# Mount static files (CSS, JS)
frontend_dir = Path(__file__).parent.parent / "frontend"
app.mount("/static", StaticFiles(directory=str(frontend_dir)), name="static")


if __name__ == "__main__":
    import uvicorn
    
    server_config = config['server']
    uvicorn.run(
        app,
        host=server_config['host'],
        port=server_config['port'],
        log_level="info"
    )
