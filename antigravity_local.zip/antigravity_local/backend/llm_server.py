"""Enhanced LLM Server with model management and multi-model support."""
import json
import os
from typing import AsyncGenerator, Dict, List, Optional
from llama_cpp import Llama
import yaml
from pathlib import Path


class ModelManager:
    """Manages multiple models and model switching"""
    
    def __init__(self, models_dir: str):
        self.models_dir = Path(models_dir)
        self.loaded_models: Dict[str, Llama] = {}
        self.current_model_name: Optional[str] = None
    
    def scan_models(self) -> List[Dict]:
        """Scan directory for available GGUF models."""
        models = []
        
        if not self.models_dir.exists():
            return models
        
        # Search for .gguf files
        for model_file in self.models_dir.rglob('*.gguf'):
            file_size_mb = model_file.stat().st_size / (1024 * 1024)
            models.append({
                'name': model_file.stem,
                'path': str(model_file),
                'size_mb': round(file_size_mb, 2),
                'loaded': str(model_file) in self.loaded_models
            })
        
        return models
    
    def load_model(self, model_path: str, **kwargs) -> Llama:
        """Load a model into memory."""
        if model_path in self.loaded_models:
            return self.loaded_models[model_path]
        
        # Convert to forward slashes for llama-cpp-python
        normalized_path = model_path.replace('\\', '/')
        
        print(f"Loading model: {normalized_path}")
        
        llm = Llama(
            model_path=normalized_path,
            n_ctx=kwargs.get('n_ctx', 8192),
            n_gpu_layers=kwargs.get('n_gpu_layers', 0),  # Default to CPU
            n_threads=kwargs.get('n_threads', 8),
            verbose=True
        )
        
        self.loaded_models[model_path] = llm
        self.current_model_name = Path(model_path).stem
        print(f"Model loaded successfully: {self.current_model_name}")
        return llm
    
    def unload_model(self, model_path: str):
        """Unload a model from memory."""
        if model_path in self.loaded_models:
            # Let garbage collector handle it
            del self.loaded_models[model_path]
    
    def get_current_model(self) -> Optional[Llama]:
        """Get the currently active model."""
        if not self.loaded_models:
            return None
        
        # Return first loaded model if current not set
        if not self.current_model_name:
            return list(self.loaded_models.values())[0]
        
        for path, model in self.loaded_models.items():
            if Path(path).stem == self.current_model_name:
                return model
        
        return None


class LLMServer:
    """Enhanced LLM server with model management."""
    
    def __init__(self, config_path: str = "../config.yaml"):
        """Initialize the LLM server with configuration."""
        self.config = self._load_config(config_path)
        self.llm = None
        self.model_manager = None
        self._initialize_model_manager()
        self._initialize_llm()
    
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _initialize_model_manager(self):
        """Initialize the model manager."""
        llm_config = self.config['llm']
        model_path = llm_config['model_path']
        models_dir = str(Path(model_path).parent.parent.parent)  # Go up to models root
        
        self.model_manager = ModelManager(models_dir)
    
    def _initialize_llm(self):
        """Initialize the llama.cpp model."""
        llm_config = self.config['llm']
        model_path = llm_config['model_path']
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at: {model_path}")
        
        print(f"Loading model from: {model_path}")
        
        self.llm = self.model_manager.load_model(
            model_path,
            n_ctx=llm_config['context_size'],
            n_gpu_layers=llm_config['gpu_layers'],
            n_threads=llm_config['threads']
        )
        
        print("Model loaded successfully!")
    
    def switch_model(self, model_path: str) -> bool:
        """Switch to a different model."""
        try:
            if not os.path.exists(model_path):
                return False
            
            llm_config = self.config['llm']
            self.llm = self.model_manager.load_model(
                model_path,
                n_ctx=llm_config['context_size'],
                n_gpu_layers=llm_config['gpu_layers'],
                n_threads=llm_config['threads']
            )
            return True
        except Exception as e:
            print(f"Error switching model: {e}")
            return False
    
    def list_available_models(self) -> List[Dict]:
        """List all available models."""
        return self.model_manager.scan_models()
    
    def create_tool_schema(self, tools: List[Dict]) -> List[Dict]:
        """Convert tools to OpenAI function calling format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["parameters"]
                }
            }
            for tool in tools
        ]
    
    async def generate_response(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict]] = None,
        stream: bool = True
    ) -> AsyncGenerator[str, None]:
        """Generate a response from the LLM with optional tool calling."""
        llm_config = self.config['llm']
        
        # Get current model
        current_llm = self.model_manager.get_current_model() or self.llm
        
        # Prepare messages in llama-cpp-python format
        chat_messages = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in messages
        ]
        
        # Add tool schemas if provided
        tool_schemas = self.create_tool_schema(tools) if tools else None
        
        if stream:
            # Streaming response
            response_stream = current_llm.create_chat_completion(
                messages=chat_messages,
                max_tokens=llm_config['max_tokens'],
                temperature=llm_config['temperature'],
                top_p=llm_config['top_p'],
                top_k=llm_config['top_k'],
                tools=tool_schemas,
                stream=True
            )
            
            for chunk in response_stream:
                if 'choices' in chunk and len(chunk['choices']) > 0:
                    delta = chunk['choices'][0].get('delta', {})
                    
                    # Handle text content
                    if 'content' in delta and delta['content']:
                        yield json.dumps({
                            'type': 'content',
                            'data': delta['content']
                        }) + '\n'
                    
                    # Handle tool calls
                    if 'tool_calls' in delta and delta['tool_calls']:
                        for tool_call in delta['tool_calls']:
                            yield json.dumps({
                                'type': 'tool_call',
                                'data': {
                                    'id': tool_call.get('id', ''),
                                    'name': tool_call['function']['name'],
                                    'arguments': tool_call['function']['arguments']
                                }
                            }) + '\n'
        else:
            # Non-streaming response
            response = current_llm.create_chat_completion(
                messages=chat_messages,
                max_tokens=llm_config['max_tokens'],
                temperature=llm_config['temperature'],
                top_p=llm_config['top_p'],
                top_k=llm_config['top_k'],
                tools=tool_schemas,
                stream=False
            )
            
            message = response['choices'][0]['message']
            
            # Return content
            if 'content' in message and message['content']:
                yield json.dumps({
                    'type': 'content',
                    'data': message['content']
                }) + '\n'
            
            # Return tool calls
            if 'tool_calls' in message and message['tool_calls']:
                for tool_call in message['tool_calls']:
                    yield json.dumps({
                        'type': 'tool_call',
                        'data': {
                            'id': tool_call['id'],
                            'name': tool_call['function']['name'],
                            'arguments': tool_call['function']['arguments']
                        }
                    }) + '\n'
    
    def get_model_info(self) -> Dict:
        """Get information about the loaded model."""
        current_model = self.model_manager.get_current_model()
        return {
            'model_name': self.model_manager.current_model_name,
            'context_size': self.config['llm']['context_size'],
            'status': 'ready' if current_model else 'not_loaded',
            'available_models': len(self.list_available_models())
        }
