"""Multi-agent system with concurrent agent support."""
import json
import uuid
from typing import List, Dict, Any, Optional
from enum import Enum
from datetime import datetime


class AgentMode(Enum):
    """Agent operation modes."""
    PLANNING = "planning"
    EXECUTION = "execution"
    VERIFICATION = "verification"
    CHAT = "chat"


class AgentSession:
    """Represents a single agent session/conversation."""
    
    def __init__(self, agent_id: str, name: str, llm_server, tool_executor):
        self.agent_id = agent_id
        self.name = name
        self.llm_server = llm_server
        self.tool_executor = tool_executor
        self.conversation_history: List[Dict[str, str]] = []
        self.mode = AgentMode.CHAT
        self.system_prompt = self._load_system_prompt()
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
    
    def _load_system_prompt(self) -> str:
        """Load the agent system prompt."""
        return f"""You are Antigravity Local Agent "{self.name}", a powerful agentic AI coding assistant.

Agent ID: {self.agent_id}

You help users with coding tasks by autonomously planning, executing, and verifying solutions.

**Your Capabilities:**
- Read, write, and edit files
- Execute PowerShell commands
- Search for files and patterns
- Fetch web content
- Navigate directory structures
- Change system settings

**Operating Modes:**
1. **PLANNING MODE**: Design your approach, break down tasks
2. **EXECUTION MODE**: Write code, make changes, implement solutions
3. **VERIFICATION MODE**: Test changes, validate correctness

**Guidelines:**
- Be proactive and autonomous when appropriate
- Explain your reasoning briefly
- Use tools effectively to complete tasks
- Always verify your work
- Communicate clearly and concisely
- You can work independently or coordinate with other agents

Current mode: CHAT mode by default. Switch to appropriate modes as needed."""
    
    def add_message(self, role: str, content: str):
        """Add a message to the conversation history."""
        self.conversation_history.append({
            "role": role,
            "content": content
        })
        self.last_activity = datetime.now()
    
    def get_messages_for_llm(self) -> List[Dict[str, str]]:
        """Get formatted messages for the LLM."""
        messages = [{"role": "system", "content": self.system_prompt}]
        messages.extend(self.conversation_history)
        return messages
    
    async def process_message(self, user_message: str):
        """Process a user message and generate a response."""
        self.add_message("user", user_message)
        
        tools = self.tool_executor.get_available_tools()
        messages = self.get_messages_for_llm()
        
        assistant_message = ""
        tool_calls = []
        
        # Generate initial response from LLM
        async for chunk in self.llm_server.generate_response(messages, tools=tools):
            chunk_data = json.loads(chunk)
            
            if chunk_data['type'] == 'content':
                content = chunk_data['data']
                assistant_message += content
                yield {
                    'type': 'content',
                    'content': content,
                    'agent_id': self.agent_id
                }
            
            elif chunk_data['type'] == 'tool_call':
                tool_call = chunk_data['data']
                tool_calls.append(tool_call)
                
                yield {
                    'type': 'tool_call_start',
                    'tool_name': tool_call['name'],
                    'arguments': tool_call['arguments'],
                    'agent_id': self.agent_id
                }
        
        if assistant_message:
            self.add_message("assistant", assistant_message)
        
        # Execute tool calls
        if tool_calls:
            for tool_call in tool_calls:
                tool_name = tool_call['name']
                
                try:
                    if isinstance(tool_call['arguments'], str):
                        arguments = json.loads(tool_call['arguments'])
                    else:
                        arguments = tool_call['arguments']
                except json.JSONDecodeError:
                    yield {
                        'type': 'tool_error',
                        'error': f"Failed to parse tool arguments",
                        'agent_id': self.agent_id
                    }
                    continue
                
                result = await self.tool_executor.execute_tool(tool_name, arguments)
                
                yield {
                    'type': 'tool_result',
                    'tool_name': tool_name,
                    'result': result,
                    'agent_id': self.agent_id
                }
                
                tool_result_msg = f"[Tool: {tool_name}] Result: {json.dumps(result, indent=2)}"
                self.add_message("assistant", tool_result_msg)
                
                if result.get('success'):
                    messages = self.get_messages_for_llm()
                    follow_up = ""
                    
                    async for chunk in self.llm_server.generate_response(messages, tools=None):
                        chunk_data = json.loads(chunk)
                        if chunk_data['type'] == 'content':
                            content = chunk_data['data']
                            follow_up += content
                            yield {
                                'type': 'content',
                                'content': content,
                                'agent_id': self.agent_id
                            }
                    
                    if follow_up:
                        self.add_message("assistant", follow_up)


class AgentManager:
    """Manages multiple concurrent agents."""
    
    def __init__(self, llm_server, tool_executor):
        self.llm_server = llm_server
        self.tool_executor = tool_executor
        self.agents: Dict[str, AgentSession] = {}
        
        # Create default agent
        self.create_agent("Main Agent")
    
    def create_agent(self, name: str) -> str:
        """Create a new agent session."""
        agent_id = str(uuid.uuid4())[:8]
        agent = AgentSession(agent_id, name, self.llm_server, self.tool_executor)
        self.agents[agent_id] = agent
        return agent_id
    
    def get_agent(self, agent_id: str) -> Optional[AgentSession]:
        """Get an agent by ID."""
        return self.agents.get(agent_id)
    
    def list_agents(self) -> List[Dict]:
        """List all active agents."""
        return [
            {
                'id': agent.agent_id,
                'name': agent.name,
                'mode': agent.mode.value,
                'message_count': len(agent.conversation_history),
                'created_at': agent.created_at.isoformat(),
                'last_activity': agent.last_activity.isoformat()
            }
            for agent in self.agents.values()
        ]
    
    def delete_agent(self, agent_id: str) -> bool:
        """Delete an agent session."""
        if agent_id in self.agents:
            del self.agents[agent_id]
            return True
        return False
    
    def clone_agent(self, agent_id: str, new_name: str) -> Optional[str]:
        """Clone an existing agent with its conversation history."""
        if agent_id not in self.agents:
            return None
        
        source_agent = self.agents[agent_id]
        new_agent_id = str(uuid.uuid4())[:8]
        new_agent = AgentSession(new_agent_id, new_name, self.llm_server, self.tool_executor)
        new_agent.conversation_history = source_agent.conversation_history.copy()
        new_agent.mode = source_agent.mode
        
        self.agents[new_agent_id] = new_agent
        return new_agent_id
