// Antigravity Local Enhanced - Frontend JavaScript

class AntigravityEnhanced {
    constructor() {
        this.ws = null;
        this.isConnected = false;
        this.currentMessageDiv = null;
        this.currentAgentId = null;
        this.agents = [];
        this.models = [];

        this.initializeElements();
        this.attachEventListeners();
        this.connectWebSocket();
        this.loadAgents();
        this.loadModels();
        this.checkStatus();
    }

    initializeElements() {
        this.messagesContainer = document.getElementById('messages');
        this.userInput = document.getElementById('user-input');
        this.sendBtn = document.getElementById('send-btn');
        this.statusDot = document.getElementById('status-dot');
        this.statusText = document.getElementById('status-text');
        this.agentList = document.getElementById('agent-list');
        this.modelSelector = document.getElementById('model-selector');
        this.currentAgentName = document.getElementById('current-agent-name');
        this.settingsModal = document.getElementById('settings-modal');
    }

    attachEventListeners() {
        // Send message
        this.sendBtn.addEventListener('click', () => this.sendMessage());

        // Enter to send
        this.userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Auto-resize textarea
        this.userInput.addEventListener('input', () => {
            this.userInput.style.height = 'auto';
            this.userInput.style.height = this.userInput.scrollHeight + 'px';
        });

        // New agent button
        document.getElementById('new-agent-btn').addEventListener('click', () => this.createNewAgent());

        // Clear chat
        document.getElementById('clear-chat-btn').addEventListener('click', () => this.clearChat());

        // Model selector
        this.modelSelector.addEventListener('change', () => this.switchModel());

        // Refresh models
        document.getElementById('refresh-models-btn').addEventListener('click', () => this.loadModels());

        // Settings
        document.getElementById('settings-btn').addEventListener('click', () => {
            this.settingsModal.style.display = 'flex';
        });

        document.getElementById('close-settings').addEventListener('click', () => {
            this.settingsModal.style.display = 'none';
        });
    }

    async checkStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();

            if (data.status === 'ready') {
                this.updateStatus('Ready', true);
                this.sendBtn.disabled = false;
            } else {
                this.updateStatus('Initializing...', false);
            }
        } catch (error) {
            this.updateStatus('Error', false);
            console.error('Status check failed:', error);
        }
    }

    updateStatus(text, isReady) {
        this.statusText.textContent = text;
        if (isReady) {
            this.statusDot.classList.add('ready');
        } else {
            this.statusDot.classList.remove('ready');
        }
    }

    connectWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/chat`;

        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
            console.log('WebSocket connected');
            this.isConnected = true;
            this.updateStatus('Ready', true);
            this.sendBtn.disabled = false;
        };

        this.ws.onmessage = (event) => {
            const message = JSON.parse(event.data);
            this.handleMessage(message);
        };

        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.updateStatus('Connection Error', false);
        };

        this.ws.onclose = () => {
            console.log('WebSocket disconnected');
            this.isConnected = false;
            this.updateStatus('Disconnected', false);
            this.sendBtn.disabled = true;

            // Attempt to reconnect
            setTimeout(() => this.connectWebSocket(), 3000);
        };
    }

    async loadAgents() {
        try {
            const response = await fetch('/api/agents');
            const data = await response.json();
            this.agents = data.agents || [];
            this.renderAgents();

            // Set first agent as current
            if (this.agents.length > 0 && !this.currentAgentId) {
                this.currentAgentId = this.agents[0].id;
                this.currentAgentName.textContent = this.agents[0].name;
            }
        } catch (error) {
            console.error('Failed to load agents:', error);
        }
    }

    renderAgents() {
        this.agentList.innerHTML = '';

        this.agents.forEach(agent => {
            const agentItem = document.createElement('div');
            agentItem.className = 'agent-item';
            if (agent.id === this.currentAgentId) {
                agentItem.classList.add('active');
            }

            agentItem.innerHTML = `
                <div class="agent-item-name">${agent.name}</div>
                <div class="agent-item-meta">${agent.message_count} messages</div>
            `;

            agentItem.addEventListener('click', () => {
                this.currentAgentId = agent.id;
                this.currentAgentName.textContent = agent.name;
                this.renderAgents();
                this.clearMessages();
            });

            this.agentList.appendChild(agentItem);
        });
    }

    async createNewAgent() {
        const name = prompt('Enter agent name:');
        if (!name) return;

        try {
            const response = await fetch('/api/agents/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });

            const data = await response.json();
            if (data.success) {
                await this.loadAgents();
                this.currentAgentId = data.agent_id;
                this.currentAgentName.textContent = name;
            }
        } catch (error) {
            console.error('Failed to create agent:', error);
        }
    }

    async loadModels() {
        try {
            const response = await fetch('/api/models');
            const data = await response.json();
            this.models = data.models || [];

            this.modelSelector.innerHTML = '';
            this.models.forEach(model => {
                const option = document.createElement('option');
                option.value = model.path;
                option.textContent = `${model.name} (${model.size_mb}MB)`;
                if (model.path.includes(data.current)) {
                    option.selected = true;
                }
                this.modelSelector.appendChild(option);
            });
        } catch (error) {
            console.error('Failed to load models:', error);
        }
    }

    async switchModel() {
        const modelPath = this.modelSelector.value;

        try {
            const response = await fetch('/api/models/switch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model_path: modelPath })
            });

            const data = await response.json();
            if (data.success) {
                console.log('Switched to model:', data.current_model);
            }
        } catch (error) {
            console.error('Failed to switch model:', error);
        }
    }

    sendMessage() {
        const message = this.userInput.value.trim();

        if (!message || !this.isConnected) return;

        // Display user message
        this.addUserMessage(message);

        // Send to backend
        this.ws.send(JSON.stringify({
            type: 'message',
            content: message,
            agent_id: this.currentAgentId
        }));

        // Clear input
        this.userInput.value = '';
        this.userInput.style.height = 'auto';

        // Show loading
        this.showLoading();
    }

    addUserMessage(content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user';

        messageDiv.innerHTML = `
            <div class="message-avatar">👤</div>
            <div class="message-content">
                ${this.escapeHtml(content)}
            </div>
        `;

        this.messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    }

    showLoading() {
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message assistant';
        loadingDiv.id = 'loading-indicator';

        loadingDiv.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">
                <div class="loading">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
            </div>
        `;

        this.messagesContainer.appendChild(loadingDiv);
        this.scrollToBottom();
    }

    removeLoading() {
        const loading = document.getElementById('loading-indicator');
        if (loading) {
            loading.remove();
        }
    }

    handleMessage(message) {
        if (message.type === 'content') {
            this.removeLoading();
            this.addAssistantContent(message.content);
        }
        else if (message.type === 'tool_call_start') {
            this.removeLoading();
            this.addToolExecution(message.tool_name, message.arguments);
        }
        else if (message.type === 'tool_result') {
            this.updateToolResult(message.tool_name, message.result);
        }
        else if (message.type === 'complete') {
            this.removeLoading();
            this.currentMessageDiv = null;
            this.loadAgents(); // Refresh agent list
        }
        else if (message.type === 'error') {
            this.removeLoading();
            this.addErrorMessage(message.message || 'An error occurred');
        }
    }

    addAssistantContent(content) {
        if (!this.currentMessageDiv) {
            this.currentMessageDiv = document.createElement('div');
            this.currentMessageDiv.className = 'message assistant';
            this.currentMessageDiv.innerHTML = `
                <div class="message-avatar">🤖</div>
                <div class="message-content"></div>
            `;
            this.messagesContainer.appendChild(this.currentMessageDiv);
        }

        const contentDiv = this.currentMessageDiv.querySelector('.message-content');
        const currentText = contentDiv.textContent || '';
        const newText = currentText + content;

        // Render markdown
        contentDiv.innerHTML = marked.parse(newText);

        // Apply syntax highlighting
        contentDiv.querySelectorAll('pre code').forEach((block) => {
            hljs.highlightElement(block);
        });

        this.scrollToBottom();
    }

    addToolExecution(toolName, args) {
        const toolDiv = document.createElement('div');
        toolDiv.className = 'tool-execution';
        toolDiv.id = `tool-${toolName}-${Date.now()}`;

        toolDiv.innerHTML = `
            <span class="tool-name">Tool: ${toolName}</span>
            <div class="tool-args">${JSON.stringify(args, null, 2)}</div>
            <div class="tool-status">Executing...</div>
        `;

        this.messagesContainer.appendChild(toolDiv);
        this.scrollToBottom();
    }

    updateToolResult(toolName, result) {
        const toolDivs = document.querySelectorAll('.tool-execution');
        const latestToolDiv = Array.from(toolDivs).reverse().find(div =>
            div.querySelector('.tool-name').textContent.includes(toolName)
        );

        if (latestToolDiv) {
            const statusDiv = latestToolDiv.querySelector('.tool-status');
            if (result.success) {
                statusDiv.textContent = 'Success';
                statusDiv.style.color = 'var(--success)';
            } else {
                statusDiv.textContent = `Error: ${result.error || 'Unknown error'}`;
                statusDiv.style.color = 'var(--error)';
            }
        }
    }

    addErrorMessage(errorText) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'message assistant';

        errorDiv.innerHTML = `
            <div class="message-avatar">⚠️</div>
            <div class="message-content" style="background: var(--error); color: white;">
                <strong>Error:</strong> ${this.escapeHtml(errorText)}
            </div>
        `;

        this.messagesContainer.appendChild(errorDiv);
        this.scrollToBottom();
    }

    clearChat() {
        if (confirm('Clear this chat?')) {
            this.clearMessages();
        }
    }

    clearMessages() {
        const welcomeMessage = this.messagesContainer.querySelector('.welcome-message');
        this.messagesContainer.innerHTML = '';
        if (welcomeMessage) {
            this.messagesContainer.appendChild(welcomeMessage);
        }
    }

    scrollToBottom() {
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.antigravity = new AntigravityEnhanced();
});
